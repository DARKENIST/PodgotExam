﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestirPodgotExam
{
    public class Calculator
    {
        public double Add(double a, double b) => a + b;
        public double Subtract(double a, double b) => a - b;
        public double Multiply(double a, double b) => a * b;
        public double Divide(double a, double b)
        {
            if (b == 0)
                throw new DivideByZeroException("Делить на ноль нельзя.");
            return a / b;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var calc = new Calculator();
            Console.WriteLine("Простой калькулятор");
            Console.WriteLine("Доступные операции: +, -, *, /");

            double a = ReadDouble("Введите первое число: ");
            if (double.IsNaN(a)) return; 

            Console.Write("Введите операцию: ");
            string? op = Console.ReadLine();
            if (string.IsNullOrEmpty(op))
            {
                Console.WriteLine("Операция не введена.");
                return;
            }

            double b = ReadDouble("Введите второе число: ");
            if (double.IsNaN(b)) return;

            double result;
            try
            {
                switch (op)
                {
                    case "+": result = calc.Add(a, b); break;
                    case "-": result = calc.Subtract(a, b); break;
                    case "*": result = calc.Multiply(a, b); break;
                    case "/": result = calc.Divide(a, b); break;
                    default:
                        Console.WriteLine("Неизвестная операция.");
                        return;
                }
                Console.WriteLine($"Результат: {result}");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        static double ReadDouble(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine();
                if (input == null) 
                {
                    Console.WriteLine("Ввод недоступен.");
                    return double.NaN;
                }
                if (double.TryParse(input, out double result))
                    return result;
                Console.WriteLine("Некорректное число. Попробуйте снова.");
            }
        }
    }
}
