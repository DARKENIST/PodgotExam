﻿namespace TestirPodgotExam
{
    [TestClass]
    public class CalculatorTests
    {
        private Calculator _calc;

        [TestInitialize]
        public void Setup()
        {
            _calc = new Calculator();
        }

        [TestMethod]
        public void Add_TwoPositiveNumbers_ReturnsCorrectSum()
        {
            double result = _calc.Add(5.5, 4.5);
            Assert.AreEqual(10.0, result, 0.0001);
        }

        [TestMethod]
        public void Divide_TwoValidNumbers_ReturnsCorrectQuotient()
        {
            double result = _calc.Divide(10, 2);
            Assert.AreEqual(5.0, result, 0.0001);
        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void Divide_ByZero_ThrowsDivideByZeroException()
        {
            _calc.Divide(5, 0);
        }
    }
}
